<?php

define('BASEURL', 'http://localhost/phpmvc/public');


//DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', null);
define('DB_NAME', 'phpmvc');