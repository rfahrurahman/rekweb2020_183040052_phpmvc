<?php



class User_model {
	private $nama = 'Rizki Caesar';

	public function getUser() 
	{
	
		return $this->nama;
	
	}
}